const fileSystem = require('fs');
const textFromFile = fileSystem.readFileSync('./sample.csv','utf-8');
console.log(textFromFile);

let maleSet = [];
let femaleSet =[];


  for (let i = 0; i <= textFromFile.length; i++) {
    maleSet[i] = textFromFile.slice(",");
  }
  console.log(maleSet);