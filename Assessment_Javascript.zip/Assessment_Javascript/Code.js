const ps = require("prompt-sync");
const prompt = ps();
var percentage = 0;
let name1 = "Jill"//prompt("Enter first name to match with : ");
let name2  = "Jack"//prompt("Enter second name to match with :");
let sentence = name1+" matches "+name2;
console.log(sentence);
const count = {};

 for (let i = 0; i <= sentence.length -1; i++) {
    const letter = sentence[i];

    if (!count[letter] ) 
        count[letter] = 1;
  
     else 
        count[letter]++;
  }
  let sum =0;
  function sumall(){
  for (var key in count) {
   var value = count[key];
   sum +=value;
  }
  return sum+sumall();
}
  console.log(sumall());